# Online Python compiler (interpreter) to run Python online.
# Write Python 3 code in this online editor and run it.
# Get started with interactive Python!
# Supports Python Modules: builtins, math,pandas, scipy 
# matplotlib.pyplot, numpy, operator, processing, pygal, random, 
# re, string, time, turtle, urllib.request
import matplotlib.pyplot as plt
#inserting dummy data
power_values = [0.8, 1.2, 1.5, 1.8, 2.1, 2.4, 2.7, 3.0]
delay_values = [0.6, 0.45, 0.35, 0.28, 0.22, 0.18, 0.15, 0.12]
#creating the plot
plt.figure(figsize=(8, 6))
#plotting the data points
plt.plot(delay_values, power_values, marker='o', linestyle='-', color='b')
#adding labels and title
plt.title('Power vs. Delay Plot',fontsize=16)
plt.xlabel('Propagation Delay (ns)',fontsize=12)
plt.ylabel('Power Consumption (nW)',fontsize=12)
#adding grid to make it easier to read
plt.grid(True)
#save and showing the plot
plt.savefig('power_vs_delay_plot.png')